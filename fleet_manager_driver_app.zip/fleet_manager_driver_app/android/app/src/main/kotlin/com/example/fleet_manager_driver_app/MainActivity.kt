package com.example.fleet_manager_driver_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
