import 'dart:io';
import 'package:fleet_manager_driver_app/utils/color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../controller/navigation_controller.dart';
import '../widget/toaster_message.dart';
import 'main_screen.dart';

class NavigationScreen extends StatefulWidget {
  const NavigationScreen({super.key});

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

File? _imageFile;
String? _issueSelection;

class _NavigationScreenState extends State<NavigationScreen> {

  NavigationController controller = Get.put(NavigationController());
  RxBool _obscureTextPin = true.obs;


  Future<void> _pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);

    if (image != null) {
      setState(() {
        _imageFile = File(image.path);
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
/*      appBar: AppBar(
        title:  Container(
          margin: const EdgeInsets.symmetric(vertical:10,horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: greenlight.withOpacity(.1),
          ),
          child: TextFormField(
            decoration: InputDecoration(
              border: InputBorder.none,
              labelText: 'Search',
              labelStyle: const TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),
              prefixIcon: const Icon(Icons.search),
            ),
          ),
        ),
        backgroundColor: secondary,
      ),*/
      backgroundColor: secondary,
      body: Container(
        //margin: const EdgeInsets.only(top:10),
        //height: MediaQuery.of(context).size.height*.65,
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: greenlight, width: 2),
            left: BorderSide(color: greenlight, width: 2),
            right: BorderSide(color: greenlight, width: 2),
            bottom: BorderSide(color: greenlight, width: 2),
          ),
        ),
        child: GoogleMap(
          initialCameraPosition: CameraPosition(
            target: LatLng(37.42796133580664, -122.085749655962),
            zoom: 15,
          ),
          markers: {
            Marker(
              markerId: const MarkerId('marker_1'),
              position: const LatLng(37.42796133580664, -122.085749655962),
              icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
              infoWindow: const InfoWindow(
                title: 'Google',
                snippet: 'Googleplex',),
            ),
          },
        ),
      ),
      floatingActionButton: Stack(
        children:<Widget> [
          Positioned(
            right: 5,
            bottom: 50,
            child: Container(
                decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.transparent),
                padding: const EdgeInsets.only(left:4,right:4,top:4,bottom:45),
                child: FloatingActionButton(
                  backgroundColor: primary,
                  onPressed: () {
                    showDetailOverLay();
                  },
                  child: const Icon(Icons.menu_rounded, color: Colors.white, size: 30,),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(100.0),
                  ),
                ),
              ),
          ),
          Positioned(
            right: 5,
            bottom: 120, // Adjust this value as needed
            child: Container(
                decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.transparent),
                padding: const EdgeInsets.only(left:4,right:4,top:4,bottom:45),
                child: FloatingActionButton(
                  backgroundColor: Colors.red[700],
                  onPressed: () {
                    print("Dashboard");
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return buildSosAlert();
                      },
                    );
                  },
                  child: const Icon(Icons.sos, color: Colors.white, size: 30,),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(100.0),
                  ),
                ),
              ),
          ),
          Positioned(
            right: 5,
            bottom: 190, // Adjust this value as needed
            child: Container(
                decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.transparent),
                padding: const EdgeInsets.only(left:4,right:4,top:4,bottom:45),
                child: FloatingActionButton(
                  backgroundColor: greenlight,
                  onPressed: () {
                    controller.callHelp();
                  },
                  child: const Icon(Icons.call, color: Colors.white, size: 30,),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(100.0),
                  ),
                ),
              ),
          ),
        ],
      )
    );
  }

  Widget buildSosAlert() {
    return SingleChildScrollView(
      child: StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return AlertDialog(
            backgroundColor: secondary,
            title: Center(child: Text("SOS ALERT", style: GoogleFonts.lato(color: primary, fontSize: 18, fontWeight: FontWeight.w700))),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  decoration: InputDecoration(
                    labelText: 'Enter your message',
                    labelStyle: TextStyle(color: primary, fontSize: 13, fontWeight: FontWeight.w500),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: primary.withOpacity(.7)),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: primary),
                    ),
                  ),
                ),
                SizedBox(height: 20,),

                if (_imageFile != null)
                  Column(
                    children: [
                      Image.file(_imageFile!),
                      SizedBox(height: 20,),
                    ],
                  ),
                Center(
                  child: ElevatedButton(
                    style: ButtonStyle(
                      elevation: MaterialStateProperty.all(5),
                      backgroundColor: WidgetStateProperty.all(primary),
                    ),
                    onPressed: () async {
                      await _pickImage();
                      setState(() {});
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_a_photo_rounded, color: Colors.white, size: 18,),
                        const SizedBox(width: 10),
                        Text(
                          'ADD  IMAGE',
                          style: GoogleFonts.lato(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    //Text('Capture Image',style:TextStyle(color: Colors.white, fontSize: 13,)),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  _imageFile = null;
                  Navigator.of(context).pop();
                },
                child: Text("CANCEL", style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),),
              ),

              TextButton(
                onPressed: () {
                  _imageFile = null;
                  Navigator.of(context).pop();
                },
                child: Text("SUBMIT", style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),),
              ),
            ],
          );
        },
      ),
    );
  }


  Widget buildStopAlert() {
    return SingleChildScrollView(
      child: StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return AlertDialog(
            backgroundColor: secondary,
            title: Center(child: Text("STOP", style: GoogleFonts.lato(color: primary, fontSize: 18, fontWeight: FontWeight.w700))),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Do you want to report any issues?', style: TextStyle(color: primary, fontWeight: FontWeight.w500)),
                RadioListTile<String>(
                  title: const Text('Yes', style: TextStyle(color: primary,fontSize: 14, fontWeight: FontWeight.w500)),
                  value: 'yes',

                  groupValue: _issueSelection,
                  onChanged: (value) {
                    setState(() {
                      _issueSelection = value;
                    });
                  },
                ),
                RadioListTile<String>(
                  title: const Text('No', style: TextStyle(color: primary,fontSize: 14, fontWeight: FontWeight.w500)),
                  value: 'no',
                  groupValue: _issueSelection,
                  onChanged: (value) {
                    setState(() {
                      _issueSelection = value;
                    });
                  },
                ),
                if (_issueSelection == 'yes') ...[
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: 'Enter your issue',
                      labelStyle: TextStyle(color: primary, fontSize: 13, fontWeight: FontWeight.w500),
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: primary.withOpacity(.7)),
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: primary),
                      ),
                    ),
                  ),
                  SizedBox(height: 20,),
                  if (_imageFile != null)
                    Column(
                      children: [
                        Image.file(_imageFile!),
                        SizedBox(height: 20,),
                      ],
                    ),
                  Center(
                    child: ElevatedButton(
                      style: ButtonStyle(
                        elevation: MaterialStateProperty.all(5),
                        backgroundColor: WidgetStateProperty.all(primary),
                      ),
                      onPressed: () async {
                        await _pickImage();
                        setState(() {});
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add_a_photo_rounded, color: Colors.white, size: 18,),
                          const SizedBox(width: 10),
                          Text(
                            'ADD  IMAGE',
                            style: GoogleFonts.lato(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  _imageFile = null;
                  Navigator.of(context).pop();
                },
                child: Text("CANCEL", style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),),
              ),
              TextButton(
                onPressed: () {
                  _imageFile = null;
                  Navigator.of(context).pop();
                  showSetPinOverLay();
                },
                child: Text("SUBMIT", style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),),
              ),
            ],
          );
        },
      ),
    );
  }


  /*Widget buildStopAlert() {
    return SingleChildScrollView(
      child: StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return AlertDialog(
            backgroundColor: secondary,
            title: Center(child: Text("STOP", style: GoogleFonts.lato(color: primary, fontSize: 18, fontWeight: FontWeight.w700))),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  decoration: InputDecoration(
                    labelText: 'Is there any issue?',
                    labelStyle: TextStyle(color: primary, fontSize: 13, fontWeight: FontWeight.w500),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: primary.withOpacity(.7)),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: primary),
                    ),
                  ),
                ),
                SizedBox(height: 20,),

                if (_imageFile != null)
                  Column(
                    children: [
                      Image.file(_imageFile!),
                      SizedBox(height: 20,),
                    ],
                  ),
                Center(
                  child: ElevatedButton(
                    style: ButtonStyle(
                      elevation: MaterialStateProperty.all(5),
                      backgroundColor: WidgetStateProperty.all(primary),
                    ),
                    onPressed: () async {
                      await _pickImage();
                      setState(() {});
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_a_photo_rounded, color: Colors.white, size: 18,),
                        const SizedBox(width: 10),
                        Text(
                          'ADD  IMAGE',
                          style: GoogleFonts.lato(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  _imageFile = null;
                  Navigator.of(context).pop();
                },
                child: Text("CANCEL", style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),),
              ),
              TextButton(
                onPressed: () {
                  _imageFile = null;
                  Navigator.of(context).pop();
                  showSetPinOverLay();
                },
                child: Text("SUBMIT", style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),),
              ),
            ],
          );
        },
      ),
    );
  }*/

  showSetPinOverLay() async {
    Get.bottomSheet(
      SafeArea(
        child: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
              child: Container(
                decoration: const BoxDecoration(
                  color: secondary,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    Text(
                      'ENTER YOUR PIN',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: primary),
                    ),

                    const SizedBox(height: 20),
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: greenlight.withOpacity(.1),
                      ),
                      child: Obx(() =>
                          TextFormField(
                            obscureText: _obscureTextPin.value,
                            controller: controller.pinController,
                            maxLength: 4,
                            keyboardType: TextInputType.number,
                            inputFormatters: <TextInputFormatter>[
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            decoration: InputDecoration(
                              counterText: "",
                              prefixIcon: const Icon(Icons.password),
                              prefixIconColor: primary,
                              border: InputBorder.none,
                              labelText: 'PIN',
                              labelStyle: const TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _obscureTextPin.value
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: primary,
                                ),
                                onPressed: () => _obscureTextPin.toggle(),
                              ),
                            ),
                          )
                      ),
                    ),


                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 5,
                        backgroundColor: greenlight,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      onPressed: () async {
                        SharedPreferences prefs = await SharedPreferences.getInstance();
                        String storedPin = prefs.getString('pin') ?? '';
                        if (controller.pinController.text == '1111') {
                          Get.offAll(() => MainScreen());
                        } else {
                          print('Incorrect PIN');
                          createToastTop('Incorrect PIN');

                        }
                      },
                      child: const Text('SUBMIT', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),

              ),
            );
          },
        ),
      ),
      isScrollControlled: true,
    );
  }


  showDetailOverLay() async {
    Get.bottomSheet(
      SafeArea(
        child: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
              child: Container(
                width: Get.width,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/image/audi.png', height: 130, width: 130),
                        ],
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: Get.width*.5,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(
                              color: greenlight.withOpacity(.1),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child:Row(
                                children:[
                                  Icon(Icons.location_pin, color: greenlight, size: 25),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text('Lucknow', style: TextStyle(color: primary, fontSize: 18, fontWeight: FontWeight.w600),
                                        maxLines: 2, overflow: TextOverflow.ellipsis),
                                  ),
                                ]
                            ),
                          ),
                          const SizedBox(height: 15),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                  onPressed: (){
                                    showSetPinOverLay();
                                  },
                                  style: ButtonStyle(
                                    backgroundColor: MaterialStateProperty.all(greenlight),
                                    elevation: MaterialStateProperty.all(5),
                                  ),
                                  child: const Text('PAUSE', style: TextStyle(color: Colors.white),)),

                              const SizedBox(width: 20),
                              ElevatedButton(
                                  onPressed: (){
                                    print("Dashboard");
                                    showDialog(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return buildStopAlert();
                                      },
                                    );
                                  },
                                  style: ButtonStyle(
                                    backgroundColor: MaterialStateProperty.all(primary),
                                    elevation: MaterialStateProperty.all(5),
                                  ),
                                  child: const Text('STOP', style: TextStyle(color: Colors.white),)),
                            ],
                          ),

                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
      isScrollControlled: true,
    );
  }

}
