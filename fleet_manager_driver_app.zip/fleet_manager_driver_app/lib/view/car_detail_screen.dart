import 'dart:io';

import 'package:fleet_manager_driver_app/utils/color.dart';
import 'package:fleet_manager_driver_app/view/body_condition_screen.dart';
import 'package:fleet_manager_driver_app/widget/toaster_message.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

import '../controller/car_detail_controller.dart';

class CarDetailScreen extends StatefulWidget {
  const CarDetailScreen({super.key});

  @override
  State<CarDetailScreen> createState() => _CarDetailScreenState();
}
File? _imageFile;

class _CarDetailScreenState extends State<CarDetailScreen> {
  final CarDetailController controller = Get.put(CarDetailController());

  Future<void> _pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);

    if (image != null) {
      setState(() {
        _imageFile = File(image.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: secondary,
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.all(30),
          child: Column(
            children: [
              SizedBox(height: 20,),
              buildDashboardBox(),
              buildBodyConditionBox(),
              SizedBox(height: 15,),
              Divider(color: greenlight.withOpacity(.3),thickness: 1,),
              SizedBox(height: 10,),
              buildCheckBox(),
              SizedBox(height: 15,),
              Divider(color: greenlight.withOpacity(.3),thickness: 1,),
              SizedBox(height: 15,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Image.asset("assets/image/audi.png",height: 140,),
                  SizedBox(width: 10,),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onTap: controller.checkboxValues.every((value) => value) & controller.isDashboard ? (){
                          controller.showSetPinOverLay();
                          print("Take Handover");
                        }:
                            (){
                          createToastBottom("Please check all the fields");
                            },
                        child: Container(
                          decoration: BoxDecoration(
                            color: controller.checkboxValues.every((value) => value) & controller.isDashboard ? greenlight:greenlight.withOpacity(.4),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child:Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Text("TAKE HANDOVER",style: GoogleFonts.lato(color: Colors.white,fontSize: 12,fontWeight: FontWeight.w700,height: 1.2),),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildDashboardBox(){
    return GestureDetector(
      onTap: (){
        print("Dashboard");
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return buildDashboardAlert();
          },
        );
      },
      child: Container(
        margin: const EdgeInsets.only(top: 10,left: 5,right: 5),
        height: 110,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          image: DecorationImage(
            image: AssetImage('assets/image/dashboard.png'),
            fit: BoxFit.fill,
          ),
        ),
        child:Stack(
          fit: StackFit.expand,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  colors: [Colors.black.withOpacity(.85), primary.withOpacity(.5)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25.0,vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("DASHBOARD",style: GoogleFonts.lato(color: greenlight,fontSize: 16,fontWeight: FontWeight.w900,height: 1.2),),
                        SizedBox(height: 5,),
                        SizedBox(
                            width: MediaQuery.of(context).size.width*.6,
                            child: Text("Inspect and top off engine oil, coolant, brake fluid, and power steering fluid levels as necessary. Check battery terminals for corrosion and ensure the battery is securely mounted.",style: TextStyle(color: Colors.white.withOpacity(.7),fontSize: 8),maxLines: 3,)
                        ),
                      ],
                    ),
                    Icon(Icons.arrow_forward_ios_sharp,color: Colors.white,size: 25,)
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildBodyConditionBox(){
    return GestureDetector(
      onTap: (){
        print("Body Condition");
        Get.to(() => BodyConditionScreen());
      },
      child: Container(
        margin: const EdgeInsets.only(top: 10,left: 5,right: 5),
        height: 110,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          image: DecorationImage(
            image: AssetImage('assets/image/body_condition.png'),
            fit: BoxFit.fill,
          ),
        ),
        child:Stack(
          fit: StackFit.expand,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  colors: [Colors.black.withOpacity(.85), primary.withOpacity(.5)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25.0,vertical: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            width: MediaQuery.of(context).size.width*.3,
                            child:
                            Text("BODY CONDITION",style: GoogleFonts.lato(color: greenlight,fontSize: 16,fontWeight: FontWeight.w900,height: 1.2,))),
                        SizedBox(height: 5,),
                        SizedBox(width: MediaQuery.of(context).size.width*.6,
                            child: Text("Check for dents, scratches, rust, or damage.Inspect for cracks or chips. Ensure windows open and close properly. Check side and rearview mirrors for cracks or damage.",style: TextStyle(color: Colors.white.withOpacity(.7),fontSize: 8),maxLines: 3,)),
                      ],
                    ),
                    Icon(Icons.arrow_forward_ios_sharp,color: Colors.white,size: 25,)
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


  Widget buildCheckBox() {
    return Column(
      children: [
        ...List.generate(controller.checkboxValues.length, (index) {
          return Container(
            margin: const EdgeInsets.only(bottom: 5),
            //width: MediaQuery.of(context).size.width*.5,
            child: ListTile(
              minTileHeight: 20,
                tileColor: controller.checkboxValues[index] ? greenlight.withOpacity(.5):greenlight.withOpacity(.1),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
                title: Text(controller.checkboxTexts[index],style: TextStyle(color: primary.withOpacity(.7), fontSize: 13,),),
                trailing: Transform.scale(
                  scale: 0.6,
                  child: Checkbox(
                    value: controller.checkboxValues[index],
                    activeColor: primary,
                    onChanged: (value) {
                      setState(() {
                        controller.checkboxValues[index] = value!;
                      });
                    },
                  ),
                ),
            ),
          );
        }),

        Container(
          width: MediaQuery.of(context).size.width*.85,
          decoration: BoxDecoration(
            color: greenlight.withOpacity(.1),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Alignment and Balancing",style: TextStyle(color: primary.withOpacity(.7), fontSize: 13,),),
                Padding(
                  padding: const EdgeInsets.only(right: 10.0),
                  child: Text("458 Kms",style: TextStyle(color: primary.withOpacity(.7), fontSize: 13,),),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget buildDashboardAlert() {
    return SingleChildScrollView(
      child: StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return AlertDialog(
            backgroundColor: secondary,
            title: Text("DASHBOARD", style: GoogleFonts.lato(color: primary, fontSize: 18, fontWeight: FontWeight.w700)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  decoration: InputDecoration(
                    labelText: "Odometer Reading",
                    labelStyle: TextStyle(color: primary, fontSize: 13,fontWeight: FontWeight.w500),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: primary.withOpacity(.7)),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: primary),
                    ),
                  ),
                ),
                SizedBox(height: 10,),
                TextField(
                  decoration: InputDecoration(
                    labelText: 'Fuel Level',
                    labelStyle: TextStyle(color: primary, fontSize: 13, fontWeight: FontWeight.w500),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: primary.withOpacity(.7)),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: primary),
                    ),
                  ),
                ),
                SizedBox(height: 20,),
      
                if (_imageFile != null)
                  Column(
                    children: [
                      Image.file(_imageFile!),
                      SizedBox(height: 20,),
                    ],
                  ),
                Center(
                  child: ElevatedButton(
                    style: ButtonStyle(
                      elevation: MaterialStateProperty.all(5),
                      backgroundColor: WidgetStateProperty.all(primary),
                    ),
                    onPressed: () async {
                      await _pickImage();
                      setState(() {});
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_a_photo_rounded, color: Colors.white, size: 18,),
                        const SizedBox(width: 10),
                        Text(
                          'ADD  IMAGE',
                          style: GoogleFonts.lato(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    //Text('Capture Image',style:TextStyle(color: Colors.white, fontSize: 13,)),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  _imageFile = null;
                  setState(() {
                    controller.isDashboard=false;
                  });
                  print(controller.isDashboard);
                  Navigator.of(context).pop();
                },
                child: Text("CANCEL", style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),),
              ),

              TextButton(
                onPressed: () {
                  _imageFile = null;
                  setState(() {
                    controller.isDashboard=true;
                  });
                  print(controller.isDashboard);
                  Navigator.of(context).pop();
                },
                child: Text("SUBMIT", style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),),
              ),
            ],
          );
        },
      ),
    );
  }
}
