import 'package:fleet_manager_driver_app/utils/color.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class BodyConditionScreen extends StatefulWidget {
  const BodyConditionScreen({super.key});

  @override
  State<BodyConditionScreen> createState() => _BodyConditionScreenState();
}

class _BodyConditionScreenState extends State<BodyConditionScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: secondary,
      body:ListView(
        scrollDirection: Axis.vertical,
        children: [
          GestureDetector(
            onTap: (){
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return buildIssueAlert('FRONT VIEW','assets/image/fontview_scratch1.jpg');
                },
              );
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0,vertical: 10),
              child: Container(
                height: MediaQuery.of(context).size.width*0.8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white,
                  image: DecorationImage(
                    image: AssetImage('assets/image/suv_front.jpg'),
                    fit: BoxFit.fill,
                  ),
                ),
                child:Stack(
                    fit: StackFit.expand,
                    children: [
                      DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: greenlight.withOpacity(.2),width: 2),

                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding:  EdgeInsets.only(top:10.0),
                              child: Text('FRONT VIEW',style: GoogleFonts.lato(color: Colors.black,fontSize: 20,fontWeight: FontWeight.w800),),
                            ),
                          ],
                        ),
                      ),
                    ],
                ),
              ),
            ),
          ),

          GestureDetector(
            onTap: (){
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return buildIssueAlert('BACK VIEW','assets/image/backviewscratch.jpeg');
                },
              );
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0,vertical: 10),
              child: Container(
                height: MediaQuery.of(context).size.width*0.8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white,
                  image: DecorationImage(
                    image: AssetImage('assets/image/svu_back.jpg'),
                    fit: BoxFit.fill,
                  ),
                ),
                child:Stack(
                  fit: StackFit.expand,
                  children: [
                    DecoratedBox(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: greenlight.withOpacity(.2),width: 2),

                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top:10.0),
                            child: Text('BACK VIEW',style: GoogleFonts.lato(color: Colors.black,fontSize: 20,fontWeight: FontWeight.w800),),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          GestureDetector(
            onTap: (){
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return buildIssueAlert('RIGHT SIDE VIEW','assets/image/sideviewscratch1.jpg');
                },
              );
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0,vertical: 10),
              child: Container(
                height: MediaQuery.of(context).size.width*0.8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white,
                  image: DecorationImage(
                    image: AssetImage('assets/image/suv_side1.jpg'),
                    fit: BoxFit.fill,
                  ),
                ),
                child:Stack(
                  fit: StackFit.expand,
                  children: [
                    DecoratedBox(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: greenlight.withOpacity(.2),width: 2),

                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top:10.0),
                            child: Text('RIGHT SIDE VIEW',style: GoogleFonts.lato(color: Colors.black,fontSize: 20,fontWeight: FontWeight.w800),),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          GestureDetector(
            onTap: (){
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return buildIssueAlert('LEFT SIDE VIEW','assets/image/sideviewscratch.jpeg');
                },
              );
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0,vertical: 10),
              child: Container(
                height: MediaQuery.of(context).size.width*0.8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white,
                  image: DecorationImage(
                    image: AssetImage('assets/image/suv_side2.jpg'),
                    fit: BoxFit.fill,
                  ),
                ),
                child:Stack(
                  fit: StackFit.expand,
                  children: [
                    DecoratedBox(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: greenlight.withOpacity(.2),width: 2),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top:10.0),
                            child: Text('LEFT SIDE VIEW',style: GoogleFonts.lato(color: Colors.black,fontSize: 20,fontWeight: FontWeight.w800),),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(height: 10,),
        ],
      ),
    );
  }

  AlertDialog buildIssueAlert(title,imgPath) {
    return AlertDialog(
      title: Center(child: Text(title,style: GoogleFonts.lato(color: Colors.black,fontSize: 20,fontWeight: FontWeight.w800))),
      backgroundColor: secondary,
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(imgPath),
            SizedBox(height: 20,),
            Image.asset(imgPath),
            SizedBox(height: 20,),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: //Icon(Icons.close,color: Colors.white,),
              Text('CLOSE',style: GoogleFonts.lato(color: Colors.white,fontSize: 12,fontWeight: FontWeight.w600),),
              style: ButtonStyle(
                elevation: MaterialStateProperty.all(8),
                backgroundColor: MaterialStateProperty.all(greenlight),
                shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(25))),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
