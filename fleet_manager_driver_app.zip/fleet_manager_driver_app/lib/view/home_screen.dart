import 'package:fl_chart/fl_chart.dart';
import 'package:fleet_manager_driver_app/view/car_detail_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../controller/home_controller.dart';
import '../utils/color.dart';
import '../widget/toaster_message.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();

}

class _HomeScreenState extends State<HomeScreen> {
  final HomeController controller = Get.find();

  int _index = 2;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: secondary,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20),
            buildTripCard(),
            SizedBox(height: 20),
            buildWorkChart(),
            SizedBox(height: 20),
            Container(
                margin: const EdgeInsets.symmetric(vertical: 30, horizontal: 30),
                child: Divider(color: greenlight.withOpacity(.3), thickness: 1)),
            Container(
              child:Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children:[
                  GestureDetector(
                    onTap: (){
                      if (!controller.isKeyTaked) {
                        controller.showTakeAKeyOverLay();
                      } else {
                        createToastBottom("Please release the key");
                      }
                      },
                    child: Container(
                      decoration: BoxDecoration(
                        color: greenlight,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Text("TAKE A KEY", style: const TextStyle(color:Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                  SizedBox(width: 20),
                  GestureDetector(
                    onTap: () {
                      if (controller.isKeyTaked) {
                        Get.to(() => CarDetailScreen());
                      } else {
                        createToastBottom("Please take a key first");
                        //Get.snackbar("Error", "Please take a key first");
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: primary,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Text("TAKE A CAR", style: const TextStyle(color:Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }


  Widget buildTripCard(){
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 30, horizontal: 5),
      child: Container(
        height: MediaQuery.of(context).size.width / 2.7, // Card height
        child: PageView.builder(
          itemCount: controller.trips.length,
          controller: PageController(viewportFraction: 0.36, initialPage: 2),
          onPageChanged: (index) => setState(() => _index = index),
          itemBuilder: (context, index) {
            double scale = _index == index ? 1 : .7; // Scale up if it's the middle card
            return AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              curve: Curves.fastOutSlowIn,
              child: Transform.scale(
                scale: scale,
                child: Container(
                  //width: MediaQuery.of(context).size.width / 2.5,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    image: DecorationImage(
                      image: AssetImage(controller.trips[index].carImage),
                      fit: BoxFit.fill, // Make the image fill the container
                    ),
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: _index == index ? primary.withOpacity(.3): Colors.black.withOpacity(.2),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left:20.0, right: 10.0,top:15, bottom: 10.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(controller.trips[index].carName, style:  TextStyle(color:Colors.white.withOpacity(.9), fontSize: 12, fontWeight: FontWeight.w300)),
                                  Icon(Icons.add, color: Colors.white, size: 12),
                                ],
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(controller.trips[index].vehicleLocation, style: const TextStyle(color:Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                                  Container(
                                    width: MediaQuery.of(context).size.width * 0.18,
                                    color: greenlight,
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 3.0),
                                      child: Row(
                                        children: [
                                          const Icon(Icons.calendar_today, color: Colors.white, size: 10,),
                                          SizedBox(width: 3),
                                          Text(DateFormat('dd/MM/yy').format(controller.trips[index].tripDate), style: const TextStyle(color:Colors.white, fontSize: 10, fontWeight: FontWeight.w400)),
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 2),
                                  Container(
                                    width: MediaQuery.of(context).size.width * 0.28,
                                    color: greenlight,
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 3.0),
                                      child: Row(
                                        children: [
                                          const Icon(Icons.access_time_rounded, color: Colors.white, size: 10,),
                                          SizedBox(width: 3),
                                          Text("12:00AM- 6:00PM", style: const TextStyle(color:Colors.white, fontSize: 10, fontWeight: FontWeight.w400)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget buildWorkChart() {
    return Column(
      children: [
        Container(
            margin: const EdgeInsets.symmetric(vertical: 0, horizontal: 30),
            child:Column(
                children:[
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left:10.0),
                        child: Text("WORK CHART", style: const TextStyle(color:primary, fontSize: 12, fontWeight: FontWeight.w700)),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children:[
                        Container(
                          height: 65,
                          decoration: BoxDecoration(
                            color: secondary,
                            border: Border.all(color: greenlight, width: .25),
                          ),
                          child:Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children:[
                                Padding(
                                  padding: const EdgeInsets.only(top:5.0),
                                  child: Text("Total Hours", style: const TextStyle(color:Colors.grey, fontSize: 8, fontWeight: FontWeight.w400)),
                                ),
                                Text("2723", style: const TextStyle(color:greenlight, fontSize: 12, fontWeight: FontWeight.w900)),
                                Image.asset('assets/graph/graph1.png', width:75 ),
                              ]
                          ),
                        ),
                        Container(
                          height: 65,
                          decoration: BoxDecoration(
                            color: secondary,
                            border: Border.all(color: greenlight, width: .25),
                          ),
                          child:Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children:[
                                Padding(
                                  padding: const EdgeInsets.only(top:5.0),
                                  child: Text("Total Trips", style: const TextStyle(color:Colors.grey, fontSize: 8, fontWeight: FontWeight.w400)),
                                ),
                                Text("2,142,950", style: const TextStyle(color:greenlight, fontSize: 12, fontWeight: FontWeight.w900)),
                                Image.asset('assets/graph/graph1.png', width:75 ),
                              ]
                          ),
                        ),
                        Container(
                          height: 65,
                          decoration: BoxDecoration(
                            color: secondary,
                            border: Border.all(color: greenlight, width: .25),
                          ),
                          child:Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children:[

                                Padding(
                                  padding: const EdgeInsets.only(top:5.0),
                                  child: Text("This Year", style: const TextStyle(color:Colors.grey, fontSize: 8, fontWeight: FontWeight.w400)),
                                ),
                                Text("232,000", style: const TextStyle(color:greenlight, fontSize: 12, fontWeight: FontWeight.w900)),
                                Image.asset('assets/graph/graph1.png', width:75 ),
                              ]
                          ),
                        ),
                        Container(
                          height: 60,
                          child:Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children:[
                                Text("Work Progress", style: const TextStyle(color:Colors.grey, fontSize: 8, fontWeight: FontWeight.w400)),
                                Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    SizedBox(
                                      height: 45, // specify the height
                                      width: 45, // specify the width
                                      child: CircularProgressIndicator(
                                          value: 0.75,color: greenlight,
                                          backgroundColor: Colors.grey.withOpacity(.3),
                                          strokeWidth: 3,
                                        ),
                                    ),
                                    Text(
                                      "75%",
                                      style: const TextStyle(color: greenlight, fontSize: 12, fontWeight: FontWeight.w900),
                                    ),
                                  ],
                                ),
                              ]
                          ),
                        ),
                      ]
                  ),
                ]
            )
        ),
        SizedBox(height: 30),
        //buildChart(context),
        Container(
          margin: const EdgeInsets.only(top: 20, right: 30,left:20),
          height: 120,
          width: MediaQuery.of(context).size.width * 0.9,
          child: LineChart(
            LineChartData(
              minY: 0,
              gridData: FlGridData(
                show: true,
                getDrawingHorizontalLine: (value) {
                  return FlLine(
                    color: greenlight,
                    strokeWidth: 0.3,
                    dashArray: [2, 5],
                  );
                },
                drawVerticalLine: false,
              ),
              borderData: FlBorderData(show: false,),
              titlesData: FlTitlesData(
                show: true,
                topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 30,
                    interval: 1,
                    getTitlesWidget: bottomTitleWidgets,
                  ),
                ),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    interval: 1000,
                    getTitlesWidget: leftTitleWidgets,
                    reservedSize: 28,
                  ),
                ),
              ),
              backgroundColor: secondary,
              lineBarsData: [
                LineChartBarData(
                  spots: [
                    FlSpot(1, 2500),
                    FlSpot(2, 3500),
                    FlSpot(3, 500),
                    FlSpot(4, 4000),
                    FlSpot(5, 4500),
                    FlSpot(6, 5500),
                    FlSpot(7, 3500),
                    FlSpot(8, 4500),
                  ],
                  dotData: FlDotData(
                    getDotPainter: (spot, percent, barData, index) {
                      return FlDotCirclePainter(
                        color: greenlight,
                        radius: 4,
                      );
                    },
                  ),
                  color: primary,
                  barWidth: 2,
                  //belowBarData: BarAreaData(show: true, color: greenlight.withOpacity(.3)),

                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget bottomTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      fontWeight: FontWeight.w300,
      color: Colors.grey,
      fontSize: 6,
    );
    Widget text;
    switch (value.toInt()) {
      case 1:
        text = const Text('JAN', style: style);
        break;
      case 2:
        text = const Text('FEB', style: style);
        break;
      case 3:
        text = const Text('MAR', style: style);
        break;
      case 4:
        text = const Text('APR', style: style);
        break;
      case 5:
        text = const Text('MAY', style: style);
        break;
      case 6:
        text = const Text('JUN', style: style);
        break;
      case 7:
        text = const Text('JUL', style: style);
        break;
      case 8:
        text = const Text('AUG', style: style);
        break;
      case 9:
        text = const Text('SEP', style: style);
        break;
      case 10:
        text = const Text('OCT', style: style);
        break;
      case 11:
        text = const Text('NOV', style: style);
        break;
      case 12:
        text = const Text('DEC', style: style);
        break;
      default:
        text = const Text('', style: style);
        break;
    }
    return SideTitleWidget(
      axisSide: meta.axisSide,
      child: text,
    );
  }

  Widget leftTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      fontWeight: FontWeight.w300,
      color: Colors.grey,
      fontSize: 6,
    );
    String text;
    switch (value.toInt()) {
      case 1000:
        text = '1000';
        break;
      case 2000:
        text = '2000';
        break;
      case 3000:
        text = '3000';
        break;
      case 4000:
        text = '4000';
        break;
      case 5000:
        text = '5000';
        break;
      case 6000:
        text = '6000';
        break;
      case 7000:
        text = '7000';
        break;
      case 8000:
        text = '8000';
        break;
      case 9000:
        text = '9000';
        break;
      case 10000:
        text = '10000';
        break;
      default:
        return Container();
    }

    return Text(text, style: style, textAlign: TextAlign.left);
  }

}




