import 'package:flutter/material.dart';
import 'color.dart';

final myTheme = ThemeData(
  primarySwatch: primaryColor,
);
