import 'package:fleet_manager_driver_app/utils/color.dart';
import 'package:fleet_manager_driver_app/widget/toaster_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/user.dart';
import '../service/global.dart';



class LoginController extends GetxController{
  RxList<User> users = RxList.empty();
  RxBool isLoggedIn = false.obs;
  final pinController1 = TextEditingController();
  final pinController2 = TextEditingController();
  RxBool _obscureText1 = true.obs;
  RxBool _obscureText2 = true.obs;

@override
  Future<void> onInit() async {
    super.onInit();
    users.add(User(0001,'samuel','samuel','Samuel',1234567890,'Thrissur','KL123466',DateTime.parse('2025-04-06T08:43:49.359+00:00'),'assets/profileimg/person1.jpg'));
    users.add(User(0002,'john','john','John',1234567890,'Wayanad','KL123466',DateTime.parse('2025-04-08T08:43:49.359+00:00'),'assets/profileimg/person2.jpeg'));
    users.add(User(0003,'jacob','jacob','Jacob',1234567890,'Kochi','KL123466',DateTime.parse('2025-04-10T08:43:49.359+00:00'),'assets/profileimg/person3.jpeg'));
    print('User data added ////////////////////////////////////////////////');

    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey('userName') && prefs.containsKey('password') && prefs.containsKey('id'))
      print(prefs.getString('userName')!);
      loggedInUserId = int.parse(prefs.getString('id')!);
      isLoggedIn(true);
}

  login(usernameController, passwordController) async {
    for (var user in users) {
      if (user.userName == usernameController.text && user.password == passwordController.text) {
        loggedInUserId = user.id;
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString('userName', usernameController.text);
        prefs.setString('password', passwordController.text);
        prefs.setString('id', user.id.toString());
        print('Logged in as ${loggedInUserId}');
        return true;
      }
    }
    return false;
  }


  showSetPinOverLay() async {
    Get.bottomSheet(
      SafeArea(
        child: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
              child: Container(
                decoration: const BoxDecoration(
                  color: secondary,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                     Text(
                    'SET SECURITY PIN',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: primary),
                    ),

                    const SizedBox(height: 20),
                     Container(
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                       decoration: BoxDecoration(
                         borderRadius: BorderRadius.circular(30),
                         color: greenlight.withOpacity(.1),
                       ),
                       child: Obx(() =>
                           TextFormField(
                         controller: pinController1,
                         obscureText: _obscureText1.value,
                         maxLength: 4,
                         keyboardType: TextInputType.number,
                         inputFormatters: <TextInputFormatter>[
                           FilteringTextInputFormatter.digitsOnly
                         ],
                        decoration: InputDecoration(
                          counterText: "",
                          prefixIcon: const Icon(Icons.password),
                          prefixIconColor: primary,
                          border: InputBorder.none,
                          labelText: 'PIN',
                          labelStyle: const TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscureText1.value
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: primary,
                            ),
                            onPressed: () => _obscureText1.toggle(),
                          ),
                        ),
                       )
                       ),
                     ),
                    const SizedBox(height: 20),
                     Container(
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                       decoration: BoxDecoration(
                         borderRadius: BorderRadius.circular(30),
                         color: greenlight.withOpacity(.1),
                       ),
                       child: Obx(() =>
                           TextFormField(
                          controller: pinController2,
                         obscureText: _obscureText2.value,
                         maxLength: 4,
                         keyboardType: TextInputType.number,
                         inputFormatters: <TextInputFormatter>[
                           FilteringTextInputFormatter.digitsOnly
                         ],
                        decoration: InputDecoration(
                          counterText: "",
                          prefixIcon: const Icon(Icons.password),
                          prefixIconColor: primary,
                          border: InputBorder.none,
                          labelText: 'CONFIRM PIN',
                          labelStyle: const TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscureText2.value
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: primary,
                            ),
                            onPressed: () => _obscureText2.toggle(),
                          ),
                        ),
                       ),
                       ),
                     ),

                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 5,
                        backgroundColor: greenlight,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      onPressed: () async {
                        if (pinController1.text == pinController2.text) {
                          SharedPreferences prefs = await SharedPreferences.getInstance();
                          prefs.setString('pin', "1111");
                          print('Pin set');
                          pinController1.clear();
                          pinController2.clear();

                          Get.back();
                        } else {
                          print('Pin not match');
                          createToastTop('Pin not match');
                        }
                      },
                      child: const Text('Set Pin', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              
              ),
            );
          },
        ),
      ),
      isScrollControlled: true,
    );
  }
}