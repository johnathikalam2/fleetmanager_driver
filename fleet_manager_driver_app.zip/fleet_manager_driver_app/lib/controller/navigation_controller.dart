import 'package:fleet_manager_driver_app/utils/color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../view/main_screen.dart';
import '../widget/toaster_message.dart';

class NavigationController extends GetxController {
  static NavigationController get to => Get.find();
  TextEditingController pinController = TextEditingController();



  /*showDetailOverLay() async {
    Get.bottomSheet(
      SafeArea(
        child: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
              child: Container(
                width: Get.width,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset('assets/image/audi.png', height: 130, width: 130),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: Get.width*.5,
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                decoration: BoxDecoration(
                                  color: greenlight.withOpacity(.1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child:Row(
                                  children:[
                                    Icon(Icons.location_pin, color: greenlight, size: 25),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text('Lucknow', style: TextStyle(color: primary, fontSize: 18, fontWeight: FontWeight.w600),
                                      maxLines: 2, overflow: TextOverflow.ellipsis),
                                    ),
                                  ]
                                ),
                              ),
                              const SizedBox(height: 15),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ElevatedButton(
                                      onPressed: (){
                                        showSetPinOverLay();
                                      },
                                      style: ButtonStyle(
                                        backgroundColor: MaterialStateProperty.all(greenlight),
                                        elevation: MaterialStateProperty.all(5),
                                      ),
                                      child: const Text('PAUSE', style: TextStyle(color: Colors.white),)),

                                  const SizedBox(width: 20),
                                  ElevatedButton(
                                      onPressed: (){
                                        print("Dashboard");
                                        showDialog(
                                          context: context,
                                          builder: (BuildContext context) {
                                            return buildSosAlert();
                                          },
                                        );
                                      },
                                      style: ButtonStyle(
                                        backgroundColor: MaterialStateProperty.all(primary),
                                        elevation: MaterialStateProperty.all(5),
                                      ),
                                      child: const Text('STOP', style: TextStyle(color: Colors.white),)),
                                ],
                              ),

                            ],
                          ),
                        ],
                      ),
                ),
              ),
            );
          },
        ),
      ),
      isScrollControlled: true,
    );
  }

  showSetPinOverLay() async {
    Get.bottomSheet(
      SafeArea(
        child: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
              child: Container(
                decoration: const BoxDecoration(
                  color: secondary,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    Text(
                      'ENTER YOUR PIN',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: primary),
                    ),

                    const SizedBox(height: 20),
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: greenlight.withOpacity(.1),
                      ),
                      child: Obx(() =>
                          TextFormField(
                            controller: pinController,
                            obscureText: _obscureText.value,
                            maxLength: 4,
                            keyboardType: TextInputType.number,
                            inputFormatters: <TextInputFormatter>[
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            decoration: InputDecoration(
                              counterText: "",
                              prefixIcon: const Icon(Icons.password),
                              prefixIconColor: primary,
                              border: InputBorder.none,
                              labelText: 'PIN',
                              labelStyle: const TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _obscureText.value
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: primary,
                                ),
                                onPressed: () => _obscureText.toggle(),
                              ),
                            ),
                          )
                      ),
                    ),


                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 5,
                        backgroundColor: greenlight,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      onPressed: () async {
                        SharedPreferences prefs = await SharedPreferences.getInstance();
                        String storedPin = prefs.getString('pin') ?? '';
                        if (pinController.text == storedPin) {
                          Get.offAll(() => MainScreen());
                        } else {
                          print('Incorrect PIN');
                          createToastTop('Incorrect PIN');

                        }
                      },
                      child: const Text('SUBMIT', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),

              ),
            );
          },
        ),
      ),
      isScrollControlled: true,
    );
  }*/


  callHelp() async {
    if (!await launchUrl(Uri.parse('tel:+9181380 66143'))) {
      throw 'Could not launch tel:+918138066143';
    }
  }
}