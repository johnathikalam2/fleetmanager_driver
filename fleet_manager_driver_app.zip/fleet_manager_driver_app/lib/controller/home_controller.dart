import 'dart:io';

import 'package:fleet_manager_driver_app/utils/color.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/car.dart';
import '../model/chart.dart';
import '../model/trip.dart';
import '../model/user.dart';
import '../view/login_screen.dart';
import '../widget/toaster_message.dart';
import 'login_controller.dart';

class HomeController extends GetxController{
  static HomeController get to =>Get.find();
  Rx<User> loggedInUser = User(0,'','','',0,'','',DateTime.now(),'').obs;
  RxList<Trip> trips = RxList.empty();
  RxList<User> users = RxList.empty();
  RxList<Car> cars = RxList.empty();
  final carNumberController = TextEditingController();
  bool isKeyTaked = false;
  final pinController1 = TextEditingController();
  final pinController2 = TextEditingController();
  final passwordController = TextEditingController();
  RxBool _obscureText1 = true.obs;
  RxBool _obscureText2 = true.obs;
  RxBool _obscureText = true.obs;


  Rx<File?> _imageFile = Rx<File?>(null);

  Future<void> _pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);

    if (image != null) {
      _imageFile.value = File(image.path); // Assign the File to _imageFile
      update(); // Update the UI
    }
  }

  Future<void> logout() async {
    LoginController loginController = LoginController();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('userName');
    prefs.remove('password');
    prefs.remove('id');
    loginController.isLoggedIn(false);
    loggedInUser.value = User(0,'','','',0,'','',DateTime.now(),'');
    Get.offAll(() => LoginScreen());
  }

  Future<void> changePin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('pin');
    Get.back();
    Get.dialog(
      AlertDialog(
        title: Center(child: const Text('CHANGE PIN', style: TextStyle(color: primary, fontSize: 20, fontWeight: FontWeight.w600))),
        backgroundColor: secondary,
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: greenlight.withOpacity(.1),
                ),
                child: Obx(() =>
                    TextFormField(
                      controller: passwordController,
                      obscureText: _obscureText.value,
                      decoration: InputDecoration(
                        counterText: "",
                        prefixIcon: const Icon(Icons.lock_outline),
                        prefixIconColor: primary,
                        border: InputBorder.none,
                        labelText: 'PASSWORD',
                        labelStyle: const TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscureText.value
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: primary,
                          ),
                          onPressed: () => _obscureText.toggle(),
                        ),
                      ),
                    )
                ),
              ),
              const SizedBox(height: 10),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: greenlight.withOpacity(.1),
                ),
                child: Obx(() =>
                    TextFormField(
                      controller: pinController1,
                      obscureText: _obscureText1.value,
                      maxLength: 4,
                      keyboardType: TextInputType.number,
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.digitsOnly
                      ],
                      decoration: InputDecoration(
                        counterText: "",
                        prefixIcon: const Icon(Icons.password),
                        prefixIconColor: primary,
                        border: InputBorder.none,
                        labelText: 'PIN',
                        labelStyle: const TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscureText1.value
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: primary,
                          ),
                          onPressed: () => _obscureText1.toggle(),
                        ),
                      ),
                    )
                ),
              ),
              const SizedBox(height: 10),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: greenlight.withOpacity(.1),
                ),
                child: Obx(() =>
                    TextFormField(
                      controller: pinController2,
                      obscureText: _obscureText2.value,
                      maxLength: 4,
                      keyboardType: TextInputType.number,
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.digitsOnly
                      ],
                      decoration: InputDecoration(
                        counterText: "",
                        prefixIcon: const Icon(Icons.password),
                        prefixIconColor: primary,
                        border: InputBorder.none,
                        labelText: 'CONFIRM PIN',
                        labelStyle: const TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscureText2.value
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: primary,
                          ),
                          onPressed: () => _obscureText2.toggle(),
                        ),
                      ),
                    ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              passwordController.clear();
              pinController1.clear();
              pinController2.clear();
              Get.back();
            },
            child: Text("CANCEL", style: GoogleFonts.lato(fontSize: 15, color: primary, fontWeight: FontWeight.w600),),
          ),

          TextButton(
            onPressed: () async {
              if (prefs.getString('password') == passwordController.text){
                if (pinController1.text == pinController2.text ){
                  //prefs.setString('pin', pinController1.text);
                  prefs.setString('pin', '1111');
                  print('Pin set');
                  createToastTop('PIN Changed successfully');
                  passwordController.clear();
                  pinController1.clear();
                  pinController2.clear();
                  Get.back();
                } else {
                  pinController1.clear();
                  pinController2.clear();
                  print('Pin not match');
                  createToastTop('Pin not match');
                }
              } else {

                passwordController.clear();
                pinController1.clear();
                pinController2.clear();
                print('Password not match');
                createToastTop('Password not match');
              }
            },
            child: Text("CONFIRM", style: GoogleFonts.lato(fontSize: 15, color: primary, fontWeight: FontWeight.w600),),
          ),
        ],
      ),
    );
  }

  @override
  void onInit(){
    super.onInit();
    users.add(User(0001,'samuel','samuel','Samuel',1234567890,'Thrissur','KL123466',DateTime.parse('2025-04-06T08:43:49.359+00:00'),'assets/profileimg/person1.jpg'));
    users.add(User(0002,'john','john','John',1234567890,'Wayanad','KL123466',DateTime.parse('2025-04-08T08:43:49.359+00:00'),'assets/profileimg/person3.jpeg'));
    users.add(User(0003,'jacob','jacob','Jacob',1234567890,'Kochi','KL123466',DateTime.parse('2025-04-10T08:43:49.359+00:00'),'assets/profileimg/person2.jpeg'));

    cars.add(Car(0002,'KLAA000000','Ghost','assets/cars/ghost.jpg'));
    cars.add(Car(0001,'KLAA000001','Continental','assets/cars/continental.jpg'));
    cars.add(Car(0003,'KLAA000002','Mercedes','assets/cars/mercedes.jpg'));
    cars.add(Car(0004,'KLAA000003','M34i0','assets/cars/m34i0.jpg'));
    cars.add(Car(0005,'KLAA000004','Venom','assets/cars/venom.jpg'));

    trips.add(Trip(
        00001,
        'KLAB091234',
        'Mercedes',
        'assets/cars/mercedes.jpg',
        0001,
        DateTime.parse('2025-04-11T08:43:49.359+00:00'),
        1,
        90030,
        90049,
        'DOHA TO DUKAN',
        [FuelStart(2, 'assets/profileimg/person1.jpg')],
        [FuelEnd(3, 'assets/profileimg/person2.jpeg')]
    ));
    trips.add(Trip(
        00002,
        'KLAB091235',
        'Mercedes',
        'assets/cars/mercedes.jpg',
        0002,
        DateTime.parse('2025-04-12T08:43:49.359+00:00'),
        1,
        90030,
        90049,
        'DOHA TO DUKAN',
        [FuelStart(5, 'assets/profileimg/person1.jpg')],
        [FuelEnd(10, 'assets/profileimg/person2.jpeg')]
    ));
    trips.add(Trip(
        00003,
        'KLAB091236',
        'Mercedes',
        'assets/cars/mercedes.jpg',
        0003,
        DateTime.parse('2025-04-13T08:43:49.359+00:00'),
        1,
        90030,
        90035,
        'DOHA TO DUKAN',
        [FuelStart(7, 'assets/profileimg/person1.jpg')],
        [FuelEnd(15, 'assets/profileimg/person2.jpeg')]
    ));

    trips.add(Trip(
        00004,
        'KLAB091237',
        'Mercedes',
        'assets/cars/mercedes.jpg',
        0003,
        DateTime.parse('2025-04-15T08:43:49.359+00:00'),
        1,
        90030,
        90035,
        'DOHA TO DUKAN',
        [FuelStart(9, 'assets/profileimg/person1.jpg')],
        [FuelEnd(15, 'assets/profileimg/person2.jpeg')]
    ));

  }


  showTakeAKeyOverLay() async {
    String query = '';
    List<String> filteredCars = [];

    Get.bottomSheet(
      SafeArea(
        child: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return Container(
              decoration: const BoxDecoration(
                color: secondary,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 15),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                         Text(
                          'SELECT CAR',
                          style: GoogleFonts.lato(color:primary, fontWeight: FontWeight.bold, fontSize: 20),
                        ),
                        ElevatedButton(
                            style: ButtonStyle(
                              elevation: WidgetStateProperty.all(5),
                              backgroundColor: WidgetStateProperty.all(greenlight),
                            ),
                            onPressed: (){
                              Get.back();
                              Get.dialog(
                                AlertDialog(
                                  title:  Text('ADD CAR', style: GoogleFonts.lato(color: primary, fontSize: 20, fontWeight: FontWeight.w600)),
                                  backgroundColor: secondary,
                                  content: SingleChildScrollView(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        TextFormField(
                                          decoration: InputDecoration(
                                            labelText: 'Enter Car Number',
                                            labelStyle: GoogleFonts.lato(fontSize: 12, color: primary, fontWeight: FontWeight.w600),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(color: primary.withOpacity(.7)),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(color: primary),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 10),
                                        TextFormField(
                                          decoration: InputDecoration(
                                            labelText: 'Enter Car Name',
                                            labelStyle: GoogleFonts.lato(fontSize: 12, color: primary, fontWeight: FontWeight.w600),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(color: primary.withOpacity(.7)),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(color: primary),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 10),
                                        Obx(()=> _imageFile.value != null
                                            ?
                                          Image.file(_imageFile.value!)
                                            :Container(),
                                        ),
                                        const SizedBox(height: 10),

                                        ElevatedButton(
                                          onPressed: () async {
                                            await _pickImage();
                                            setState(() {});
                                          },
                                          style: ButtonStyle(
                                            elevation: WidgetStateProperty.all(5),
                                            backgroundColor: WidgetStateProperty.all(greenlight),
                                          ),
                                          child:  Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Icon(Icons.add_a_photo_rounded, color: Colors.white, size: 18,),
                                              const SizedBox(width: 10),
                                              Text(
                                                'ADD  IMAGE',
                                                style: GoogleFonts.lato(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () {
                                        _imageFile=Rx<File?>(null);
                                        Get.back();
                                      },
                                      child: Text("CANCEL", style: GoogleFonts.lato(fontSize: 15, color: primary, fontWeight: FontWeight.w600),),
                                    ),

                                    TextButton(
                                      onPressed: () {
                                        _imageFile=Rx<File?>(null);
                                        isKeyTaked = true;
                                        Get.back();
                                      },
                                      child: Text("CONFIRM", style: GoogleFonts.lato(fontSize: 15, color: primary, fontWeight: FontWeight.w600),),
                                    ),
                                  ],
                                ),
                              );
                            },
                            child: const Text('ADD CAR', style: TextStyle(color: Colors.white),)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: carNumberController,
                      onChanged: (value) {
                        query = value;
                        filteredCars = cars
                            .map((car) => car.carNumber)
                            .where((carNumber) => carNumber.contains(query))
                            .toList();
                        setState(() {});
                      },
                      decoration:  InputDecoration(
                        labelText: 'Enter Car Number',
                        labelStyle: GoogleFonts.lato(fontSize: 13, color: primary, fontWeight: FontWeight.w500),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: primary.withOpacity(.7)),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: primary),
                        ),
                      ),
                    ),
                  /*
                    TextFormField(
                      controller: carNumberController,
                      onChanged: (value) {
                        query = value.toLowerCase();
                        filteredCars = cars
                            .map((car) => car.carNumber.toLowerCase())
                            .where((carNumber) => carNumber.contains(query))
                            .toList();
                        setState(() {});
                      },
                      decoration:  InputDecoration(
                        labelText: 'Enter Car Number',
                        labelStyle: TextStyle(color: primary, fontSize: 13,),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: primary.withOpacity(.7)),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: primary),
                        ),
                      ),
                    ),*/
                    ListView.builder(
                      shrinkWrap: true,
                      itemCount: filteredCars.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(filteredCars[index]),
                          onTap: () {
                            carNumberController.text = filteredCars[index];
                            filteredCars = [];
                            setState(() {});
                          },
                        );
                      },
                    ),
                    const SizedBox(height: 10),
                    ElevatedButton(

                      onPressed: () {
                        String carNumber = carNumberController.text;
                        Car selectedCar = cars.firstWhere((car) => car.carNumber == carNumber);
                        Get.back();
                        Get.dialog(
                          AlertDialog(
                            backgroundColor: secondary,
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text('CAR NUMBER : ${selectedCar.carNumber}', style: const TextStyle(color:primary, fontSize: 16, fontWeight: FontWeight.w600)),
                                const SizedBox(height: 10),
                                Container(
                                  height: 200,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    image: DecorationImage(
                                      image: AssetImage(selectedCar.carImage),
                                      fit: BoxFit.fill, // Make the image fill the container
                                    ),
                                  ),
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      DecoratedBox(
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          border: Border.all(color: greenlight.withOpacity(.2),width: 2),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.only(left:20.0, right: 10.0,top:15, bottom: 10.0),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                children: [
                                                  Text(selectedCar.carName, style:  TextStyle(color:Colors.white.withOpacity(.9), fontSize: 16, fontWeight: FontWeight.w500)),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  carNumberController.clear();
                                  Get.back();
                                },
                                child: Text("CANCEL", style: const TextStyle(color: primary, fontSize: 16)),
                              ),
                              TextButton(
                                onPressed: () {
                                  isKeyTaked= true;
                                  Get.back();
                                },
                                child: Text("OK", style: const TextStyle(color: primary, fontSize: 16)),
                              ),
                            ],
                          ),
                        );
                      },
                      style: ButtonStyle(
                        elevation: WidgetStateProperty.all(8),
                        backgroundColor: WidgetStateProperty.all(primary),
                      maximumSize: MaterialStateProperty.all(const Size(double.infinity, 50)),
                      ),
                      child:  Text(
                        'CHECK CAR',
                        style: GoogleFonts.lato(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      isScrollControlled: true,
    );
  }
}