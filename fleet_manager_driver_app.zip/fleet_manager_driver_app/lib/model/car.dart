class Car{
  int carId;
  String carNumber;
  String carName;
  String carImage;

  Car(this.carId,
      this.carNumber,
      this.carName,
      this.carImage,
      );
}