class ChartData {
  final int month;
  final int hour;

  ChartData(this.month, this.hour);
}