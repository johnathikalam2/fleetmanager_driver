import 'dart:ffi';

class User{
  int id;
  String userName;
  String password;
  String name;
  int mobile;
  String location;
  String dlNumber;
  DateTime dlExpiry;
  String profileImg;

  User(
      this.id,
      this.userName,
      this.password,
      this.name,
      this.mobile,
      this.location,
      this.dlNumber,
      this.dlExpiry,
      this.profileImg
      );
}