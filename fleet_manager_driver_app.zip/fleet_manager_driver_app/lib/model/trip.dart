import 'dart:ffi';

class FuelStart{
  int fuelValue;
  String fuelImage;

  FuelStart(this.fuelValue, this.fuelImage);
}

class FuelEnd{
  int fuelValue;
  String fuelImage;

  FuelEnd(this.fuelValue, this.fuelImage);
}

class Trip{
  int tripId;
  String carNumber;
  String carName;
  String carImage;
  int driverId;
  DateTime tripDate;
  int revenue;
  int odometerStart;
  int odometerEnd;
  String vehicleLocation;
  List<FuelStart> fuelStart;
  List<FuelEnd> fuelEnd;



  Trip(this.tripId,
      this.carNumber,
      this.carName,
      this.carImage,
      this.driverId,
      this.tripDate,
      this.revenue,
      this.odometerStart,
      this.odometerEnd,
      this.vehicleLocation,
      this.fuelStart,
      this.fuelEnd
      );
}